package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Login() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		PrintWriter out=response.getWriter();
		ServletContext context=getServletContext();
		String driver=context.getInitParameter("driver");
		String url=context.getInitParameter("url");
		String user=context.getInitParameter("user");
		String password=context.getInitParameter("password");
		String userid=request.getParameter("id");
		String u_password=request.getParameter("password");
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url, user, password);
			ps=con.prepareStatement("select * from servlet_login");
			rs=ps.executeQuery();
			String User_Password=null;
			response.setContentType("text/html");
			while(rs.next()) {
				if(userid.equals(rs.getString(1))) {
					User_Password=rs.getString(4);
				}
			}
			if(u_password.equals(User_Password)) {
				
				request.getRequestDispatcher("/Success.html").forward(request, response);
			}
			else
			{
//				out.print(User_Password);
				request.getRequestDispatcher("/Failure.html").include(request, response);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(con!=null)
					con.close();
				if(ps!=null)
					ps.close();
				if(rs!=null)
					rs.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
