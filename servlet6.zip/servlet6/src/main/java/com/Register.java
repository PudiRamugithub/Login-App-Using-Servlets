package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Register() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("   ").append(request.getContextPath());
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		PrintWriter out=response.getWriter();
		ServletContext context=getServletContext();
		String driver=context.getInitParameter("driver");
		String url=context.getInitParameter("url");
		String user=context.getInitParameter("user");
		String password=context.getInitParameter("password");
		String userid=request.getParameter("id");
		String name=request.getParameter("name");
		double salary=Double.parseDouble(request.getParameter("salary"));
		String u_password=request.getParameter("password");
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url, user, password);
			ps=con.prepareStatement("insert into servlet_login values(?,?,?,?)");
			ps.setString(1,userid);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			ps.setString(4, u_password);
			ps.executeUpdate();
			request.getRequestDispatcher("/RegisterSuccess.html").forward(request, response);
		}
		catch(Exception e) {
//			e.printStackTrace();
			request.getRequestDispatcher("/RegisterFailure.html").include(request, response);
		}
		finally {
			try {
				if(con!=null)
					con.close();
				if(ps!=null)
					ps.close();
				if(rs!=null)
					rs.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
